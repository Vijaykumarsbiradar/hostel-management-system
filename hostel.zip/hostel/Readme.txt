"FREE SOURCE CODE" How to run the Simple Hostel Management System Project
FIRST DOWNLOAD


1.XAMPP

2."TEXT EDITOR" NOTEPAD++ OR SUBLIME TEXT 3 / ETC.

3."hostel"

4. Download the zip file/ download winrar

5. Extract the file and copy "hostel" folder

6.Paste inside root directory/ where you install xammp local disk C: drive D: drive E: paste: (for xampp/htdocs, 

7. Open PHPMyAdmin (http://localhost/phpmyadmin)

8. Create a database with name hostel

6. Import hostel.sql file(given inside the zip package in SQL file folder)

7.Run the script http://localhost/hostel


Login Details for admin : admin/Test@1234
Login Details for user : test@gmail.com/Test@123